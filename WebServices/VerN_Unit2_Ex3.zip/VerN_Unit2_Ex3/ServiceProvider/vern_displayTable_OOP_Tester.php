<?php
include('class_lib/VerN_displayTable.php');
print("<h3>");

$DB_Access = new Students_Access();
print("<hr />");
$DB_Result = $DB_Access->showDatabases( );
$rValue = "List of Databases in MySQL: <br />";
while ($row = $DB_Result->fetch_assoc()) 
{ 
	foreach($row as $value)
	{
		$rValue = $rValue . "$value <br />";
	}
}
print($rValue);

print("<hr />");
$DB_Result = $DB_Access->showTables();
$rValue = "List of Tables in students: <br />";
while ($row = $DB_Result->fetch_assoc()) 
{ 
	foreach($row as $value)
	{
		$rValue = $rValue . "$value <br />";
	}
}
print($rValue);

print("<hr />");
$table = "vern_food";
$DB_Result = $DB_Access->displayRecords($table);
$rValue = "List of Records from " . $table . " table<br />";
while($row = $DB_Result->fetch_assoc())
{ 
	foreach($row as $value)
	{
		$rValue = $rValue . "$value ";
	}
	$rValue = $rValue . "<br />";
}
print($rValue);

print("<hr />");
$id = "pizza";
$DB_Result = $DB_Access->selectOne($id);
if (is_null($DB_Result)) {
	$rValue = "No records with ID " . $id . "<br>";
} else {
	$rValue = "Record with ID " . $id . "<br>";
	while($row = $DB_Result->fetch_assoc())
	{ 
		foreach($row as $value)
		{
			$rValue = $rValue . "$value ";
		}
		$rValue = $rValue . "<br />";
	}
}
print($rValue);
print("</h3>");
?>
